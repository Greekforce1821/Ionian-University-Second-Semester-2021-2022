#include "MyRandom.h"
class Q_Add{
	private:
		int a;
        int b;
        static int MyRandom mr;
	public:
		Q_Add(int m);
		void print_quest();
        void get_Correct();
}