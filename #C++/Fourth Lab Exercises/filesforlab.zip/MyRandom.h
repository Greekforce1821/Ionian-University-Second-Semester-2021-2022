
class MyRandom{
	private:
		int rnum;
	public:
		MyRandom();
		int get_number(int m);
};