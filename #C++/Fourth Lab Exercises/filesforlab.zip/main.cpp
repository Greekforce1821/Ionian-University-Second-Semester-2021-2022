#include <iostream>
#include <iomanip>
#include "MyRandom.h"
using namespace std;

int main(){

    int correct_actions
    int summary_of_all
    int i = 1

    for (i <= 20; i++){






    }



   return (a+b)
   
}
   
  





    
  
  


